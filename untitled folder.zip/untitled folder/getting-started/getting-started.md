1. npx create-react-app reminderapp

2. npm start for run

3. Routing

    Refer AddRouting=>Add Routing.md

4. For Adding image using <img src="">
    <img src={require('../../images/Monitor.jpeg')} alt="" />

5. Add Class conditionally
    <div className={"mini-cart-box " + (miniCartToggle ? 'show' : 'hide')} >


    



