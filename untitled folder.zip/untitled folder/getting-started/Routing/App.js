import './App.css';
import './Reset.css';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Layout from './components/Layout';
import Home from './components/Pages/Home';
import Blog from './components/Pages/Blog';
import Contact from './components/Pages/Contact';
import NoPage from './components/Pages/NoPage';
import ProductDetails from './components/Pages/ProductDetails';

function App() {
  return (
   
    <BrowserRouter>
      <Routes>
      <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="blog" element={<Blog pageTitle="Blog Page"/>} />
          <Route path="contact" element={<Contact pageTitle="Contact Page"/>} />
          <Route path="product-details/:id" element={<ProductDetails />} />
          <Route path="*" element={<NoPage />} />
      </Route>
      </Routes>
    </BrowserRouter>
    
  );
}

export default App;
