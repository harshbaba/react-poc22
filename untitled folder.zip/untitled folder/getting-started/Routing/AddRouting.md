1. Routing

    Refer AddRouting=>Add Routing.md
    npm i -D react-router-dom@latest

2.  => Import BrowserRouter, Routes, Route in App.js 
        and import these method from react-router-dom
        import { BrowserRouter, Routes, Route } API from "react-router-dom";

        then import other component(pages) which you want to create route
        import Layout from './components/Layout';
        import Home from './components/Pages/Home';
        import Blog from './components/Pages/Blog';
        import Contact from './components/Pages/Contact';
        import NoPage from './components/Pages/NoPage';

3.  => Create Routes, Go to App function

        function App() {
        return (
        
            <BrowserRouter>
            <Routes>
            <Route path="/" element={<Layout />}>
                <Route index element={<Home />} />
                <Route path="blog" element={<Blog pageTitle="Blog Page"/>} />
                <Route path="contact" element={<Contact pageTitle="Contact Page"/>} />
                <Route path="product-details/:id" element={<ProductDetails />} />
                <Route path="*" element={<NoPage />} />
            </Route>
            </Routes>
            </BrowserRouter>
            
        );
        }

        =>We have created a <Route path="/" > and calling Layout component for this, this component will work as a Master Page.
        In this we will call Header & footer.

        Then Inside this Route We will nest other routes like aboutUs, 
        contact etc.

        =>Home component will treat as Landing page thats why we have used index property in <Route>
        
        <Route index element={<Home />} />

        See App.js for reference. 

4.  =>Create Master Page Go to Layout.js

        In Layout.js we have called imported Header, Footer Component and import <Outlet> from "react-router-dom"

        Using this <Outlet> we will load diiferent differnt page(component) on different Url.

5.  => For Creating the menu we have imported <link> 
        from "react-router-dom".
        Then we have creted menu link like this:

        <ul>
            <li>
                <Link to="/">Home</Link>
            </li>
            <li>
                <Link to="/blog">Blog</Link>
            </li>
            <li>
                <Link to="/contact">Contact</Link>
            </li>
        </ul>

6.  => You can pass route parameter like this

        <Link to={`/product-details/${product.id}`}></Link>
        <Route path="product-details/:id" element={<ProductDetails />} />

7. Links
    https://www.w3schools.com/react/react_router.asp
    https://v5.reactrouter.com/web/guides/quick-start


