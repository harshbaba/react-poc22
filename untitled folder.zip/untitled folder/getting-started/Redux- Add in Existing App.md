1. npm install @reduxjs/toolkit react-redux

2. Create a file named Store.js
    import { configureStore } from '@reduxjs/toolkit'

    export default configureStore({
        reducer: {},
    })

    This creates a Redux store, and also automatically configure the Redux DevTools extension so that you can inspect the store while developing.

    

Reference Links
    https://react-redux.js.org/tutorials/quick-start