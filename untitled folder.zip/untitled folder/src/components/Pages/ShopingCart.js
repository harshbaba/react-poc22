import { useSelector } from 'react-redux';

export default function ShopingCart(props){
    const products = useSelector((state) => state.shopingCart)
    console.log(products);

    return (
        <div className="shopping-cart-wrapper">
             <h2>Shopping Cart</h2>
            <div className="cart-list-box">
                <ul className="cart-list">
                    {products.map((item, index)=>{
                        return <li key={item.id}>
                                    <div className="cart-list-ind">
                                        <div className="cart-item-details">
                                            <img src={require('../../images/Monitor.jpeg')} alt="" />
                                            <h4>{item.title}</h4>
                                        </div>
                                        <div className="cart-item-quantity">
                                            <p>1</p>
                                        </div>
                                        <div className="cart-item-price">
                                            <p>{item.price}</p>
                                        </div>
                                        <div className="cart-item-total">
                                            <p>{item.price}</p>
                                        </div>
                                    </div>
                                    
                            </li>
                    })
                    }
                    
                </ul>
            </div>
        </div>
    );
}