import { Link } from "react-router-dom";
import {productsData} from '../../Data';

export default function Home(){
    
    
    return (
        <div className="home">
            
            <div className="products-list-wrapper">
                <ul className="products-list">
                    {productsData.map((product)=>{
                        
                        return <li key={product.id}>
                            <div className="product-ind">
                                <div className="product-pic">
                                    <img src={require('../../images/Monitor.jpeg')} alt="" />
                                </div>
                                <div className="product-details">
                                    <h4>{product.title}</h4>
                                    <h5>{product.price}</h5>
                                </div>
                                
                                <Link to={`/product-details/${product.id}`} className="product-link">&nbsp;</Link>
                            </div>
                        </li>
                    })}
                    
                    
                </ul>
            </div>
        </div>
    );
}