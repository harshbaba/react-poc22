import { useParams, useNavigate } from 'react-router-dom';
import { productsData } from '../../Data';
import { useDispatch } from 'react-redux';
import { addProduct } from '../../feature/shopingCartSlice';

export default function ProductDetails(){
    let { id }  = useParams();
    
    const dispatch = useDispatch();
    const navigate = useNavigate();
    
    function addToCart(id){
        let product = productsData.filter((item)=>{ 
            return item.id === id;
        });
        console.log(product);
        dispatch(addProduct(product[0]));
        navigate("../shopping-cart", { replace: true });
    }
    
    let product = productsData.filter((item)=>{
        return item.id === parseInt(id);
    });

    
    return <div className="product-details-wrapper">
                <div className="product-details-left">
                    <div className="product-pic">
                        <img src={require('../../images/Monitor.jpeg')} alt="" />
                    </div>
                </div>
                <div className="product-details-right">
                    <h3>{product[0].title}</h3>
                    <p>{product[0].shortDesc}</p>
                    <p>Price: {product[0].price}</p>
                    <button className="addcart-btn" onClick={addToCart.bind(this, product[0].id)}>Add to Cart</button>                   
                </div>
                
        </div>
        
}