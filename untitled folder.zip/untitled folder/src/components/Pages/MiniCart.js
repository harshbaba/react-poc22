import { useSelector } from 'react-redux';
import {useState, useEffect, useRef} from 'react';
export default function MiniCart(){

    //const [miniCartToggle, setMiniCartToggle] = useState(false);
    const miniCart = useRef();

    function handleMiniCart(){
        //setMiniCartToggle(!miniCartToggle);
        console.log(miniCart);
        if(miniCart.current.classList.contains('hide')){
            miniCart.current.classList.remove("hide");
            miniCart.current.classList.add("show");
        }else{
            miniCart.current.classList.add("hide");
            miniCart.current.classList.remove("show");
        }
        
        
    }
    
    const products = useSelector((state) => state.shopingCart)
    console.log(products);

    return (
        <div className="mini-cart-wrapper">
            
            <div className="mini-cart-icon" onClick={handleMiniCart}>Mini <br/> Cart</div>
            <div className="mini-cart-box hide" ref={miniCart}>
                <ul className="mini-cart-list">
                    {products.map((item)=>{
                        return <li key={item.id}>
                            <div className="mini-cart-ind">
                                <div className="mini-cart-details">
                                    <img src={require('../../images/Monitor.jpeg')} alt="" />
                                    <h4>{item.title}</h4>
                                </div>
                            </div>
                        </li>
                    })}
                    
                </ul>
            </div>
        </div>
    );
}