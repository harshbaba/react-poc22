export default function Blog(props){
    return (
        <div className="blog">
            <h3>Blog {props.name}</h3>
        </div>
    );
}