export default function NoPage(){
    return(
        <h3>NoPage</h3>
    );
}