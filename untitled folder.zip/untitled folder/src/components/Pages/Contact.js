export default function Contact(){
    return (
        <div className="contact">
            <h3>Contact</h3>
        </div>
    );
}