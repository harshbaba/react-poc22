export default function Footer(){
    return(
        <div className="layout-footer">
            <div className="container">
                <div className="footer">
                    <p>Reminder App &copy; 2021</p>
                </div>
            </div>
        </div>
    );
}