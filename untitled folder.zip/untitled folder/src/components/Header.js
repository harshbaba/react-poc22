import { Link } from "react-router-dom";
import MiniCart from './Pages/MiniCart';


function Header(){

    return (
        <div className="layout-header">
            <div className="layout-header-top">
                <div className="container">
                    <div className="header-top">
                        <h1>Logo</h1>
                        <MiniCart/>
                    </div>
                </div>
            </div>

            <div className="layout-header-bottom">
                <div className="container">
                    <div className="main-menu">
                        <ul>
                            <li>
                                <Link to="/">Home</Link>
                            </li>
                            <li>
                                <Link to="/blog">Blog</Link>
                            </li>
                            <li>
                                <Link to="/contact">Contact</Link>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Header;