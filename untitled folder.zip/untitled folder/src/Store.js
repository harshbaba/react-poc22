import { configureStore } from '@reduxjs/toolkit'
import shopingCartReducer from './feature/shopingCartSlice';

export default configureStore({
  reducer: shopingCartReducer
})