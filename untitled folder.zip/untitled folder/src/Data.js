export let productsData = [
    {
        id: 1,
        title: 'Product Title 1',
        shortDesc: 'Product Short Description',
        price: '$200'
    },
    {
        id: 2,
        title: 'Product Title 2',
        shortDesc: 'Product Short Description',
        price: '$200'
    },
    {
        id: 3,
        title: 'Product Title 3',
        shortDesc: 'Product Short Description',
        price: '$200'
    },
    {
        id: 4,
        title: 'Product Title 4',
        shortDesc: 'Product Short Description',
        price: '$200'
    },
    {
        id: 5,
        title: 'Product Title 5',
        shortDesc: 'Product Short Description',
        price: '$200'
    }
];