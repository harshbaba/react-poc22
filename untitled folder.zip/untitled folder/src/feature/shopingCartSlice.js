import { createSlice } from '@reduxjs/toolkit'

export const shopingCartSlice = createSlice({
  name: 'cart',
  initialState: {
    shopingCart: [],
  },
  reducers: {
    addProduct: (state, action) => {
      // Redux Toolkit allows us to write "mutating" logic in reducers. It
      // doesn't actually mutate the state because it uses the Immer library,
      // which detects changes to a "draft state" and produces a brand new
      // immutable state based off those changes
      state.shopingCart.push(action.payload);
    },
    deleteProduct: (state, action) => {
       
    }
  },
})

// Action creators are generated for each case reducer function
export const { addProduct, deleteProduct } = shopingCartSlice.actions

export default shopingCartSlice.reducer